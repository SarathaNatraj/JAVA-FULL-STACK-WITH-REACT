package com.demo.exercises;


import java.util.List;

public class CatalogSortedListSearch {


    //write here logic to get sorted Array List which is a global class variable
    public String catalogListSorter(List<String> unSortedCatalogList) {

        return null;
    }

    //write here logic to search the input value in sorted Array List
    public String catalogListSearcher(String value) {

        return null;
    }
}

