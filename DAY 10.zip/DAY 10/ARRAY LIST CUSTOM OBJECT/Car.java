package com.demo.exercises;

// Custom Class
public class Car {

}
