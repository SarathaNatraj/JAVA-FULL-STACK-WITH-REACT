package com.demo.exercises;


public class CarDetailsListCreation {
    //Write here logic to return global list variable
    public String getCarDetails() {

        return null;
    }

    //Write here logic to add value to global list variable
    public void setCarDetails(String modelName, String manufacturerName, int engineCapacity, String carType) {

    }

}
