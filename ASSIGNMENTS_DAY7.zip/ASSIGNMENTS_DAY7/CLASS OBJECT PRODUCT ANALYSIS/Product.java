package com.demo.oops;

/*
    Product class stores the information about a single product.
    It contains parameterized constructor and Getters/Setters
 */
public class Product {

    public Product(int productCode, String name, double price, String category) {
    }

    public int getProductCode() {
        return -1;
    }

    public void setProductCode(int productCode) {

    }

    public String getName() {
        return null;
    }

    public void setName(String name) {
    }

    public double getPrice() {
        return -1;
    }

    public void setPrice(double price) {
    }

    public String getCategory() {
        return null;
    }

    public void setCategory(String category) {

    }
}