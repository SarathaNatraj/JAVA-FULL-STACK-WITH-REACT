package com.demo.collections;

import java.time.LocalDate;

/*
Movie class has four fields- movieId,movieName, genre and releaseDate
This class should be of Comparable type comparing movies based on releaseDate
 */
public class Movie {

    public Movie(int movieId, String movieName, String genre, LocalDate releaseDate) {
    }

    public int getMovieId() {
        return 0;
    }

    public String getMovieName() {
        return null;
    }

    public String getGenre() {
        return null;
    }

    public LocalDate getReleaseDate() {
        return null;
    }
}
