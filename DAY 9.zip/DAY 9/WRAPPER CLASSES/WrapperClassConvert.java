package com.demo.commonjavaclasses;

public class WrapperClassConvert {

    //write logic to determine and convert given primitive type to its wrapper class and return result
    public Object convertToWrapper(Object input) {
        return null;
    }
psvm(){
	//Scanner input,
	//if()
	//	convertToWrapper()
	//else
	//	sop("Give proper primitive type as input")
}
}

